CREATE DATABASE Apettitgo;

use Apettitgo;