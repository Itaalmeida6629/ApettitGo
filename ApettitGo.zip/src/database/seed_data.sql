INSERT INTO Status_Pedido (nome_status) VALUES
('pendente'),
('preparando'),
('a caminho'),
('entregue'),
('cancelado');

INSERT INTO Forma_Pagamento (forma_pagamento) VALUES 
('Dinheiro'),
('Pix'),
('Cartão de Débito'),
('Cartão de Crédito')   